# Apple II Hangul 14x8 — r106 재사용 자료

Apple II 게임의 한글 출력 루틴에 맞춰 변환할 수 있는 조합형 폰트 데이터와 생성 도구다. 게임 ROM, HDV/PO 이미지, 실행 파일, 세이브, 지도, Companion, Nox 전용 패치 코드는 포함하지 않는다.

## 포함된 파일

- font.json: 14×8 자모 마스크, 문맥 뱅크, 음절별 선택자
- compose.py: 표준 Python으로 현대 한글 음절을 자모로 분해하고 14×8 픽셀로 조합하는 모듈
- golden_11172.bin: U+AC00부터 U+D7A3까지 11,172자 기대 출력
- validation.json: 마스크·뱅크·선택자·golden 검증 결과
- SHA256.json: 배포 파일 해시
- docs/사용법.md: 다른 Apple II 게임에 적용할 때의 분석 순서와 예제
- samples/: 실제 조합 결과와 셀·자모 레이어를 보여주는 PNG
- LICENSES/: 참고 폰트의 라이선스 고지
- NOTICE_DKB_SOURCE.txt: DKB 8×4×4 계열 참고 자료의 출처와 공개 범위

## 데이터 형식

한 음절은 14×8 픽셀이다. 가로 14픽셀을 7픽셀 셀 두 개로 나누며, 각 행은 왼쪽 셀 7비트와 오른쪽 셀 7비트로 저장한다. 음절 하나의 결과는 8행×2바이트=16바이트다. 각 셀에서 bit 0은 가장 왼쪽 픽셀이다.

이 자료는 완성형 음절 그림을 11,172개 저장하지 않는다. 초성·중성·종성 마스크를 문맥별로 선택해 OR 조합한다. 따라서 한 마스크를 수정하면 그 마스크를 공유하는 모든 음절을 다시 렌더링해야 한다.

## 빠른 사용

Python 3에서 다음처럼 실행한다.

    python compose.py 윈 찌 못

모듈로 사용할 때는 다음 API를 사용한다.

    from compose import decompose, layers, rows, grid, two_seven_bit_cells

    c, v, t = decompose("윈")
    masks = layers("윈")
    pixels = rows("윈")
    ascii_rows = grid("윈")
    raw16 = two_seven_bit_cells("윈")

target 게임의 인코딩, 글자 폭, 비디오 메모리, 뱅크 전환, 출력 루틴은 게임마다 다르다. 이 자료의 14×8 픽셀 결과를 target 게임의 글꼴 저장 형식으로 변환해야 하며, Nox Archaist의 $7998, $D29B, $6000, AUX $5900 주소는 재사용하지 않는다.

## 공개 범위

이 압축본은 게임과 분리된 폰트 연구·재사용 자료다. Galmuri와 NeoDunggeunmo의 라이선스 고지를 LICENSES에 포함했다. DKB 8×4×4 원본의 명시적 배포 라이선스는 확인되지 않았으므로, 공개 배포 전에는 NOTICE_DKB_SOURCE.txt를 확인하고 원저작자 허가 또는 명확한 라이선스의 자모 원본으로 교체하는 것이 필요하다.
