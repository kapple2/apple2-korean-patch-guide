"""Portable Unicode Hangul compositor. No emulator or game dependency."""
import json
from pathlib import Path
DATA=json.loads(Path(__file__).with_name('font.json').read_text(encoding='utf8'))
def decompose(ch):
    if len(ch)!=1 or not 0xAC00<=ord(ch)<=0xD7A3:raise ValueError('Expected one modern Hangul syllable')
    n=ord(ch)-0xAC00
    return n//588,n//28%21,n%28
def layers(ch):
    c,v,t=decompose(ch);ctx=DATA['context']
    vg=1 if v in ctx['double'] else 0 if v in ctx['vertical'] else 3 if v in (13,17) else 2 if v in ctx['horizontal'] else 4
    tg=0 if not t else 1 if t in (1,2,4) else 2 if t==8 else 3
    cg=3 if c==3 else 4 if c==5 else 5 if c==12 else 0 if c in (0,15) else 1 if c in (4,6,7,8,11,13,14,16,17,18) else 2
    ids=[DATA['banks'][tg*5+vg][c],DATA['banks'][20+tg*6+cg][v],DATA['banks'][44+vg][t-1] if t else 0]
    for role,gid in DATA['unicode_role_overrides'].get(ch,{}).items():ids[int(role)]=gid
    return [list(DATA['glyph_rows'][gid]) for gid in ids]
def rows(ch):
    c,v,t=layers(ch)
    return [c[y]|v[y]|t[y] for y in range(8)]
def grid(ch):
    return [''.join('#' if row>>x&1 else '.' for x in range(14)) for row in rows(ch)]
def two_seven_bit_cells(ch):
    return bytes(value for row in rows(ch) for value in (row&127,(row>>7)&127))
if __name__=='__main__':
    import sys
    for ch in ''.join(sys.argv[1:]) or '윈찌못':
        print(ch);print('\n'.join(grid(ch)))
